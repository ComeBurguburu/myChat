package com.comeb.model;

/**
 * Created by côme on 09/10/2015.
 */
public class MessageSimple extends MessageRight {
    public MessageSimple(String pseudo) {
        super(pseudo, "");
    }
}
